export class CreateUserDto {
    id: string;
    password: string;
}